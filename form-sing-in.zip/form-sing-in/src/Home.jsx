import React from "react";
import "./App.css"; //
import { Link } from "react-router-dom"; 

const Home = () => {
  return (
    <>
      {/* Navbar */}
      <nav className="navbar">
        <div className="logo">Evergreen</div>

        <input type="checkbox" id="menu-toggle" />
        <label htmlFor="menu-toggle" className="menu-icon">&#9776;</label>

        <ul className="nav-links">
          <li><a href="#">Home</a></li>
          <li><a href="./Pro">Productt</a></li>
          <li><a href="#">Services</a></li>
          <li><a href="#">Contact</a></li>
          <li>

            <Link to="/Admin">
            <button className="admin-btn">Admin</button>
            </Link>
          </li>
        </ul>
      </nav>

      {/* Page Content */}
      <div className="content">
        Krish welcome 🚀
      </div>
    </>
  );
};

export default Home;
