import React, { useEffect, useState } from 'react'
import './App.css'

const Pro = () => {
  const [products, setProducts] = useState([])

    useEffect(() => {
    let savedProducts = JSON.parse(localStorage.getItem("products")) || []
    setProducts(savedProducts)
  }, [])

  return (
    <div className="product-page">
      <h1 className="page-title">All Products</h1>
      <div className="product-grid">
        {products.length > 0 ? (
          products.map((p, index) => (
            <div className="product-card" key={index}>
              <img src={p.imageUrl} alt={p.name} />
              <h3>{p.name}</h3>
              <p>{p.desc}</p>
              <span>₹{p.price}</span>
            </div>
          ))
        ) : (
          <p>No products added yet...</p>
        )}
      </div>
    </div>
  )
}

export default Pro
